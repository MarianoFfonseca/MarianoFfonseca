import React from "react";

export default function About() {
  return (
    <div className="About">
      <h1>Acerca De Nosotros</h1>
    </div>
  );
}
