import "./index.css";
import React, { useState } from "react";
import { render } from "react-dom";
import App from "./app";

render(<App />, document.getElementById("root"));
