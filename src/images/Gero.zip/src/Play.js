import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export default function Contacts() {
  //Definir valores
  const [ganador, setGanador] = useState();
  const [op, setOp] = useState(0);
  const [finalR, setFresult] = useState(0);
  //Chechar si esta seguro
  const [sub, setSub] = useState(false);

  useEffect(() => {
    setGanador(Math.floor(Math.random() * 4 + 1));
  }, []);

  //Si gano
  const Chechear = () => {
    if (sub === true) {
      console.log(finalR, ganador);
      if (finalR === ganador) {
        return(
          <>
           <h3>Ganaste</h3>
           <Link to="/">
           <button>Volver al Incio</button>
          </Link>
           <Link to="/play">
           <button>Volver a jugar</button>
          </Link>
          </>
           );
      } else {
        return (
          <>
            <h3>Perdiste el numero era {ganador}</h3>
            <Link to="/">
              <button>Volver al Incio</button>
            </Link>
            <Link to="/play">
              <button>Volver a jugar</button>
            </Link>
            <br />
          </>
        );
      }
    }
  };
  const precionar = () => {
    setSub(true);
    setFresult(op);
  };
  const opcion1 = () => {
    setOp(1);
  };
  const opcion2 = () => {
    setOp(2);
  };
  const opcion3 = () => {
    setOp(3);
  };
  const opcion4 = () => {
    setOp(4);
  };

  return (
    <div className="Play">
      {sub === false ? (
        <div>
          <h1>Escoge un numero</h1>
          <div className="BotonesLindos">
            <button onClick={opcion1}>1</button>
            <button onClick={opcion2}>2</button>
            <button onClick={opcion3}>3</button>
            <button onClick={opcion4}>4</button>
            <br />
          </div>
          {op !== 0 ? (
            <button onClick={precionar}>submit</button>
          ) : (
            <>Selecciona tu boton</>
          )}
        </div>
      ) : (
        <></>
      )}

      {Chechear()}
    </div>
  );
}
