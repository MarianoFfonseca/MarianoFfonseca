import React from "react";
import { BrowserRouter, Switch, Route, Redirect } from "react-router-dom";
import Home from "./Home";
import About from "./About";
import Play from "./Play";
import NavBar from "./Navbar";
function App() {
  return (
    <div>
      {" "}
      <BrowserRouter>
        <NavBar />
        <Switch>
          <Route path="/" component={Home} exact />
          <Route path="/about" component={About} exact />
          <Route path="/Play" component={Play} exact />
          <Redirect to="/" />
        </Switch>
      </BrowserRouter>
    </div>
  );
}
export default App;
